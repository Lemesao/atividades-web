package edu.ifmt.cobrancaifmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CobrancaifmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
