package edu.ifmt.cobrancaifmt.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;

@Entity //Uma entidade JPA
public class Titulo {
	
	
	private Long codigo;
	private String descricao;
	private Date dataVencimento;
	private BigDecimal valor;
	private StatusTitulo status;

}

