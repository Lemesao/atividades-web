package edu.ifmt.cobrancaifmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CobrancaifmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(CobrancaifmtApplication.class, args);
	}

}
